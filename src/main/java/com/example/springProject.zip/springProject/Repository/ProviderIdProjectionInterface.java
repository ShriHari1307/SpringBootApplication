package com.example.springProject.Repository;

public interface ProviderIdProjectionInterface {
    String getProviderName();
    String getEmail();
}
