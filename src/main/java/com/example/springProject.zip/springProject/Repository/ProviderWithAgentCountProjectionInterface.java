package com.example.springProject.Repository;

public interface ProviderWithAgentCountProjectionInterface {
    String getProviderName();
    Long getAgentCount();
}
