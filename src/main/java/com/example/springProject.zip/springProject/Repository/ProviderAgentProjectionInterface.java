package com.example.springProject.Repository;

public interface ProviderAgentProjectionInterface {
    String getProviderName();
    String getProviderEmail();
    String getAgentFirstName();
    String getAgentLastName();
    String getAgentEmail();
}
