package com.example.springProject.Repository;

public interface ProviderProjectionInterface {
    public String getProviderId();
    public String getProviderName();
    public String getEmail();
}
