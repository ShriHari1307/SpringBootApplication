package com.example.springProject.Repository;

public interface ProviderCountByStateProjectionInterface {
    String getStateName();
    Long getProviderCount();
}
