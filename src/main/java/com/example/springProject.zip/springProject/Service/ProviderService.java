package com.example.springProject.Service;

import com.example.springProject.BO.AgentBO;
import com.example.springProject.BO.ProviderBO;
import com.example.springProject.DTO.ProviderDTO;
import com.example.springProject.Entity.Provider;
import com.example.springProject.Exception.ProviderManagementException;
import com.example.springProject.Exception.ProviderNotFoundException;
import com.example.springProject.Repository.ProviderAgentProjectionInterface;
import com.example.springProject.Repository.ProviderCountByStateProjectionInterface;
import com.example.springProject.Repository.ProviderIdProjectionInterface;
import com.example.springProject.Repository.ProviderProjectionInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProviderService {

    @Autowired
    private ProviderBO providerBO;

    @Autowired
    private AgentBO agentBO;

    public ProviderDTO insert(ProviderDTO providerDTO) throws ProviderManagementException {
        return providerBO.insert(providerDTO);
    }

    public ProviderDTO findProvider(String providerId) throws ProviderManagementException, ProviderNotFoundException {
        Provider provider = providerBO.findProvider(providerId);
        if (provider == null) {
            throw new ProviderNotFoundException("Provider with id: " + providerId + " not found");
        }
        return ProviderDTO.toProviderDTO(provider);
    }

    public List<ProviderDTO> findAllProviders() throws ProviderManagementException {
        List<Provider> allProviders = providerBO.findAllProviders();
        return allProviders.stream()
                .map(ProviderDTO::toProviderDTO)
                .toList();
    }

    public List<ProviderProjectionInterface> findBySelectedColumn() throws ProviderManagementException {
        return providerBO.findBySelectedColumn();
    }

    public Long countTotalProviders(){
        return providerBO.countTotalProviders();
    }

    public List<Provider> findProvidersWithMinimumAgents(){
        return providerBO.findProvidersWithMinimumAgents();
    }

    public List<ProviderCountByStateProjectionInterface> countProvidersByState(){
        return providerBO.countProvidersByState();
    }
    public List<ProviderIdProjectionInterface> findProviderNamesAndEmailsOrderedByName(){
        return providerBO.findProviderNamesAndEmailsOrdered();
    }
    public List<Provider> findProvidersInnerJoinAgents(){
        return providerBO.findProvidersInnerJoinAgents();
    }
    public List<Provider> findAllProvidersLeftJoinAgents(){
        return providerBO.findAllProvidersLeftJoinAgents();
    }
    public List<Provider> findAllProvidersRightJoinAgents(){
        return providerBO.findAllProvidersRightJoinAgents();
    }
    public List<ProviderAgentProjectionInterface> findAllProvidersCrossJoinAgents(){
        return providerBO.findAllProvidersCrossJoinAgents();
    }
    public List<Provider> findAllByOrderByCreatedAtDesc(){
        return providerBO.findAllByOrderByCreatedAtDesc();
    }

    public List<Provider> findAllWithAgents(){
        return providerBO.findAllWithAgents();
    }
}
